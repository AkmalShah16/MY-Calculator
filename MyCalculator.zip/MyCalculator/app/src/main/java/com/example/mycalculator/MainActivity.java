package com.example.mycalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;


public class MainActivity extends AppCompatActivity  implements View.OnClickListener{

    TextView resulttv, solutiontv;
    MaterialButton buttonC, buttonOpenBracket, buttonCloseBracket;
    MaterialButton buttonMul, buttonDivide, buttonPlus, buttonMinus, buttonEqual;
    MaterialButton button0, button1, button2, button3, button4, button5, button6, button7, button8, button9;
    MaterialButton buttonAC, buttonDot;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resulttv = findViewById(R.id.result_tv);
        solutiontv = findViewById(R.id.solution_tv);


        assignId(buttonC, R.id.btn_c);
        assignId(buttonOpenBracket, R.id.btn_openbracket);
        assignId(buttonCloseBracket, R.id.btn_closebracket);
        assignId(buttonDivide, R.id.btn_divide);
        assignId(button7, R.id.btn_7);
        assignId(button8, R.id.btn_8);
        assignId(button9, R.id.btn_9);
        assignId(buttonMul, R.id.btn_mul);
        assignId(button4, R.id.btn_4);
        assignId(button5, R.id.btn_5);
        assignId(button6, R.id.btn_6);
        assignId(buttonPlus, R.id.btn_plus);
        assignId(button1, R.id.btn_1);
        assignId(button2, R.id.btn_2);
        assignId(button3, R.id.btn_3);
        assignId(buttonMinus, R.id.btn_minus);
        assignId(buttonAC, R.id.btn_ac);
        assignId(button0, R.id.btn_0);
        assignId(buttonDot, R.id.btn_dot);
        assignId(buttonEqual, R.id.btn_equal);


    }
    void assignId(MaterialButton btn,int id){
        btn = findViewById(id);
        btn.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        MaterialButton button = (MaterialButton) v;
        String buttonText = button.getText().toString();
        String dataToCalculate = solutiontv.getText().toString();

        if(buttonText.equals("AC")){
            solutiontv.setText("");
            resulttv.setText("0");
            return;
        }
        if(buttonText.equals("=")){
            solutiontv.setText(resulttv.getText());
            return;
        }
        if(buttonText.equals("C")){
            dataToCalculate = dataToCalculate.substring(0,dataToCalculate.length()-1);
        }else{
            dataToCalculate = dataToCalculate+buttonText;
        }
        solutiontv.setText(dataToCalculate);
        String finalResult = getResult(dataToCalculate);

        if(!finalResult.equals("Err")){
            resulttv.setText(finalResult);
        }

    }

    String getResult(String data){
        try{
            Context context  = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            String finalResult =  context.evaluateString(scriptable,data,"Javascript",1,null).toString();
            if(finalResult.endsWith(".0")){
                finalResult = finalResult.replace(".0","");
            }
            return finalResult;
        }catch (Exception e){
            return "Err";
        }
    }


}
